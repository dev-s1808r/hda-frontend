import axios from "axios";

const api = axios.create({
  baseURL: "http://localhost:5000",
  // timeout: 5000,
  // headers: {
  //   "Content-Type": "application/json", // Default content type
  //   Authorization: `Bearer ${localStorage.getItem("token") || ""}`, // Example for auth tokens
  // },
});

export default api;
